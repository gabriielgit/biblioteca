/** @type {import('@jest/types').Config.InitialOptions} */
module.exports = {
  clearMocks: true,
  collectCoverage: true,
  testMatch: ['**/*.test.js'],
}
